package jflextest;

public class LoadException extends Exception {
  
  public LoadException(String message) {
    super(message);
  }

}
