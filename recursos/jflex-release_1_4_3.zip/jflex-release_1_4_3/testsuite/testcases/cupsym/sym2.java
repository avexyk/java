public interface sym2 {
  
  int EOF = 0;

}
